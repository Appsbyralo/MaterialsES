import SwiftUI

struct ViewA: View {
    var body: some View {
        
        ZStack {
            /*#-code-walkthrough(3.1.modifier)*/
            /*#-code-walkthrough(3.modifier)*/
            Color(.blue)
            /*#-code-walkthrough(3.1.modifier)*/
            Image(systemName: "airplane.circle")
                .foregroundColor(Color.white) 
                .font(.system(size: 100)) 
            /*#-code-walkthrough(3.modifier)*/
        }
    }
}

struct ViewA_Previews: PreviewProvider {
    static var previews: some View {
        ViewA()
    }
}

