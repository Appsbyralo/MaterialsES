import SwiftUI

struct ViewC: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let images = [
        "keynote1", "keynote2", "keynote3", "keynote4", "keynote5", "keynote6", "keynote7"
    ] + [
        "shortcuts", "shortcut1", "shortcut2", "shortcut3", "shortcut4", "shortcut5", "shortcut6", "shortcut7"
    ]
    
    @State private var imageTexts = [
        "1. Aquí puedes descargar la brújula de ideas para elegir tu mejor idea. También puedes descargar AppGPT, un chatbot que te ayuda a desarrollar tu idea de app, una presentación de One Pager para presentar tu idea de app y un análisis de tu app favorita.",
        "2. App prototipo para iPad en Keynote\nEn este archivo de Keynote recibirás un tema personalizado para desarrollar tu app prototipo para un iPad. Al hacer clic en + para agregar una nueva diapositiva, puedes elegir entre una variedad de diseños para mostrar mejor tus ideas.",
        "3. App prototipo para iPhone en Keynote\nEn este archivo de Keynote recibirás un tema personalizado para desarrollar tu app prototipo para un iPhone. Al hacer clic en + para agregar una nueva diapositiva, puedes elegir entre varios diseños para comunicar eficazmente tus ideas.",
        "4. App prototipo para MacBook en Keynote\nEn este archivo de Keynote recibirás un tema especial para crear tu app prototipo para un MacBook. Al presionar + para agregar una nueva diapositiva, puedes elegir entre varios diseños para presentar claramente tus ideas.",
        "5. App prototipo para Apple Watch en Keynote\nEn este archivo de Keynote recibirás un tema único para diseñar tu app prototipo para un Apple Watch. Al presionar + para agregar una nueva diapositiva, puedes elegir entre varios diseños para comunicar eficientemente tus ideas.",
        "6. Materiales educativos\nEn los materiales educativos recibirás recursos que te ayudarán como profesor a comenzar el proyecto 'Una App sobre Apps' con confianza. Puedes descargar un libro de Keynote que te guiará por todos los pasos desde la idea hasta la app prototipo.",
        "7. Materiales educativos en Swift\nAdemás, puedes descargar un libro de Keynote que se centra en comenzar a programar en Swift y apoyar las apps en la pestaña 'Apps' en tu clase.",
        "Crea un acceso directo para tu app",
        "1. Abre la app de Atajos en tu iPad.",
        "2. Pulsa el \"+\" para crear un nuevo acceso directo a tu pantalla de inicio.",
        "3. Busca Keynote en el campo de búsqueda. Ahora selecciona el acceso directo 'Reproducir presentación en modo espectador'.",
        "4. Pulsa en la presentación de Keynote para seleccionar el archivo que se abrirá cuando se presione el acceso directo.",
        "5. Ahora pulsa en la flecha y cambia el nombre de tu acceso directo presionando 'Renombrar'. Elige un ícono para el acceso directo y finalmente presiona 'Agregar a pantalla de inicio'.",
        "6. Pulsa en 'Agregar' para añadir el acceso directo a la pantalla de inicio.",
        "7. Ahora has creado un acceso directo en tu pantalla de inicio."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack {
                    Text("Crea un prototipo con botones de cambio de página")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("En esta página puedes descargar materiales para estudiantes, analizar tus ideas de app y elegir la mejor. También puedes descargar materiales para trabajar con tu app favorita, crear una presentación de One Pager y descargar AppGPT, un chatbot que cuestiona tu idea de app. Además, puedes descargar archivos de prototipos de apps en Keynote, diseñados para iPad, iPhone, MacBook y Apple Watch. Como profesor, también puedes descargar materiales educativos, incluyendo recursos para facilitar el proyecto de enseñanza y materiales enfocados en la programación en Swift.")
                         
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Materiales para estudiantes", description: "Haz clic aquí para descargar la brújula de ideas, AppGPT, Mi app favorita y la presentación de One Pager.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Prototipo de app para iPad", description: "Haz clic aquí para descargar el archivo de Keynote del prototipo para iPad. Desarrolla tus ideas sin problemas.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20iPad.key")
                        
                        contentBox(title: "Prototipo de app para iPhone", description: "Haz clic aquí para descargar el archivo de Keynote del prototipo para iPhone. Da vida a tus ideas de app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20iPhone.key.zip")
                        
                        contentBox(title: "Prototipo de app para Mac", description: "Haz clic aquí para descargar el archivo de Keynote del prototipo para Mac. Diseña y perfecciona tus conceptos.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20MacBook.key.zip")
                        
                        contentBox(title: "Prototipo de app para Apple Watch", description: "Haz clic aquí para descargar el archivo de Keynote del prototipo para Apple Watch. Innova y visualiza tu app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20Apple%20Watch.key")
                        
                        contentBox(title: "Material educativo", description: "Una guía completa para 'Una App sobre Apps'. Descarga libros de Keynote para facilitarte el inicio y enseñar programación en Swift.", linkURL: "https://app.box.com/s/b6a1m1jguxyx5fp6a476tbo0tfcn6gjf")
                        
                        contentBox(title: "Materiales educativos en Swift", description: "Además, puedes descargar un libro de Keynote que se enfoca en comenzar a programar en Swift y apoyar las apps en la pestaña 'Apps' en la enseñanza.", linkURL: "https://app.box.com/s/76jghz4hifyu5e4uh8egap5jk21ocwj5")
                    }
                    .padding()
                }
            }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation {
                            showPopup.toggle()
                        }
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            if showPopup {
                PopupView3(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let index = fullscreenImageIndex {
                FullscreenImageView2(images: images, descriptions: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black)
            
            Divider()
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black)
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }


struct ViewCDrawingLine {
    var points: [CGPoint]
    var color: Color
}

struct FullscreenImageView2: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.black, lineWidth: 1)
                                            )
                                    )
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                Spacer()
            }
        }
    }
}
struct PopupView3: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @State private var currentPage: Int = 0
    @State private var isFullScreen: Bool = false
    @Binding var fullscreenImageIndex: Int?
    var body: some View {
        VStack(spacing: 20) {
            Text("¿Qué es una App sobre Apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        ZStack {
                            Image(images[index])
                                .resizable()
                                .aspectRatio(contentMode: isFullScreen ? .fit : .fill)
                                .frame(width: isFullScreen ? UIScreen.main.bounds.width : 400, height: isFullScreen ? UIScreen.main.bounds.height : 300)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = index
                                    }
                                }
                            
                            if isFullScreen {
                                VStack {
                                    Spacer()
                                    Text(imageTexts[index])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                        .padding()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .transition(.opacity)
                            }
                        }
                        
                        if !isFullScreen {
                            ScrollView {
                                Text(imageTexts[index])
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 100)
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                withAnimation {
                    showPopup = false
                }
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
} 
    struct ViewC_Previews: PreviewProvider {
        static var previews: some View {
            ViewC()
        }
    }
