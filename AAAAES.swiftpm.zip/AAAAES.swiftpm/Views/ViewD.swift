import SwiftUI

struct ViewD: View {
    
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
               
                VStack {
                    Text("Apps que puedes usar como bloques y fuentes de inspiración")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)

                    Text("En esta página, debes describir qué debe incluirse en tu app, cómo debería verse y por qué. Este trabajo debe resumirse en un documento de pizarra en Freeform. Hemos creado una plantilla para ti. Puedes descargarla haciendo clic en el ícono de la app Freeform abajo. Una vez descargado el documento, debes duplicarlo. Obtén más información en el botón de información en esta página.")

                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)

                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 20) {
                            contentBox(title: "Comienza con el código", description: "Un excelente lugar para empezar tu viaje de programación.", linkURL: "")

                            contentBox(title: "Sobre mí", description: "Crea un proyecto sobre ti mismo y aprende a programar mientras construyes tu primera app.", linkURL: "")

                            contentBox(title: "Crea una barra de navegación", description: "Aprende a crear un menú con tres o más botones. Esta app está incluida en tu suscripción a 'Una App sobre Apps' en la página principal de Swift. Desplázate hacia abajo y encuentra la app de la barra de navegación.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")

                            contentBox(title: "Stack Views", description: "Aprende a posicionar objetos horizontalmente, verticalmente y a lo largo del eje Z o combinar las diferentes opciones. Esta app está incluida en tu suscripción a 'Una App sobre Apps' en la página principal de Swift. Desplázate hacia abajo y encuentra la app Stack Views.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")

                            contentBox(title: "Insertar contenido", description: "Aprende a insertar fotos, videos y enlaces en tu app. Esta app está incluida en tu suscripción a 'Una App sobre Apps' en la página principal de Swift. Desplázate hacia abajo y encuentra la app de insertar contenido.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")

                            contentBox(title: "Elementos que te ayudan a empezar", description: "Esta es una app con diferentes ideas, como mapas GPS de Apple Maps y varios tipos de botones que pueden hacer que tu app sea única. Esta app está incluida en tu suscripción a 'Una App sobre Apps' en la página principal de Swift. Desplázate hacia abajo y encuentra la app de elementos para empezar.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        }
                    }
                    }
                    .padding()
                }
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black) 
            
            Divider()  
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black) 
            
            Text("Enlace")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)  
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }


struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}

