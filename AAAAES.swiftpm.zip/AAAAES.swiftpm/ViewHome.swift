import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. An App About Apps\nEste es un proceso de diseño que te lleva desde la creación de ideas hasta la creación de prototipos de apps y finalmente a una app terminada. Este botón de información te da una visión general del contenido de la app.",
        "2. Dibujar\nEn la pestaña Dibujar puedes hacer bocetos con las herramientas integradas y explicar tus ideas, así como desarrollar diseños. Haz clic en 'Generación de ideas' para dibujar 8 ideas de apps, de las cuales más tarde podrás elegir la mejor. En 'Vacío', 'iPhone' y 'iPad' puedes diseñar los layouts de tu app en diferentes formatos.",
        "3. Libre\nCuando haces clic en Libre, puedes descargar un mapa mental en Freeform para conectar todas tus ideas. En el mapa mental, puedes arrastrar diferentes tipos de botones, marcos de iPhone y notas a tu área de trabajo. Si lo prefieres, también puedes hacer un mapa mental tradicional en papel.",
        "4. Materiales\nEn Materiales puedes descargar plantillas de Keynote para crear prototipos de tu app, ya sea para Apple Watch, iPhone, iPad o MacBook. Cada diseño de Keynote es único y ofrece diferentes plantillas para tus layouts. También puedes descargar materiales educativos para el proyecto y actividades para estudiantes. Si lo deseas, también puedes descargar materiales específicos de enseñanza sobre programación en Swift.",
        "5. Apps\nEn la pestaña Apps puedes aprender cómo comenzar a programar en Swift. Aquí puedes explorar los materiales de Apple 'Get Started with Code' y 'About Me'. Especialmente para 'Una app sobre apps', puedes descargar 4 apps que te enseñan cómo crear barras de navegación (menús), Stack Views (organización de objetos), insertar contenido (agregar texto, imágenes, videos y enlaces) y cosas para comenzar (diferentes funciones útiles).",
        "6. Portafolio\nEn la sección Portafolio puedes actualizar y documentar tu recorrido desde la idea, el diseño, la retroalimentación y los prototipos hasta la app finalizada. En el portafolio puedes subir fotos de tu galería y describir tu experiencia con texto. Al final del portafolio, puedes agregar más campos de imagen y texto."
    ]

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("An App About Apps")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    Text("Una App Sobre Apps te ayuda a pasar del desarrollo de ideas, a bocetar y describir esas ideas, hasta crear prototipos de apps. Si lo deseas, también puedes aprender a programar en Swift, para que algún día puedas publicar una app real en la App Store. ¡Haz realidad tus visiones e ideas! Haz clic en el botón de información para obtener una visión general de las diferentes secciones de la app.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Haz clic en el botón de información para obtener una visión general de las diferentes secciones de la app.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                }
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("¿Qué es una App sobre Apps??")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200)  
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

