import SwiftUI
import UIKit
import MapKit

struct MapViewRepresentable: UIViewControllerRepresentable {
    var initialLocation: CLLocationCoordinate2D
    var regionRadius: CLLocationDistance
    
    func makeUIViewController(context: Context) -> MapViewController {
        let mapViewController = MapViewController(initialLocation: initialLocation, regionRadius: regionRadius)
        return mapViewController
    }
    
    func updateUIViewController(_ uiViewController: MapViewController, context: Context) {
        // Update the view controller if needed
    }
}
