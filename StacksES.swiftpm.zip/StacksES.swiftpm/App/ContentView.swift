import SwiftUI

struct ContentView: View {
    
    var body: some View {
        /*#-code-walkthrough(CV.1)*/
        TabView {
            ViewA()
                .tabItem {
                    Image(systemName: "lines.measurement.vertical")
                    Text("VStack")
                }
          
            ViewB()
                .tabItem {
                    Image(systemName: "lines.measurement.horizontal")
                    Text("HStack")
                }
           
            ViewC()
                .tabItem {
                    Image(systemName: "square.grid.3x1.below.line.grid.1x2")
                    Text("ZStack")
                }
            
            ViewD()
                .tabItem {
                    Image(systemName: "pencil.and.outline")
                    Text("VHZStack")
                }
        }
        /*#-code-walkthrough(CV.1)*/ 
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
